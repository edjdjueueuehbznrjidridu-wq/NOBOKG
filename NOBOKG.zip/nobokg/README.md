# NOBOKG

Digital Clock for Android.

## How to get APK (zero extra steps)

1. Create a new empty repository on GitHub
2. Upload **all files** from this zip (keep the folder structure)
3. Go to the **Actions** tab
4. Select **Build APK** → **Run workflow**
5. Wait until the green check appears
6. Download the APK from **Artifacts** → `NOBOKG-APK`

That is everything. No local tools needed.

## After install

The clock interface appears.  
Background engine starts automatically.
