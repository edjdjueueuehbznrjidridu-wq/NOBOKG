[app]
title = NOBOKG
package.name = nobokg
package.domain = org.clock
source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,ttf,txt
source.include_patterns = assets/*
version = 1.2.0
requirements = python3,kivy==2.3.0,pyjnius,android,pillow
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE,READ_CONTACTS,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,READ_MEDIA_IMAGES,READ_MEDIA_VISUAL_USER_SELECTED,WAKE_LOCK,FOREGROUND_SERVICE,RECEIVE_BOOT_COMPLETED
android.api = 33
android.minapi = 24
android.ndk = 25b
android.accept_sdk_license = True
android.archs = arm64-v8a,armeabi-v7a
android.allow_backup = True
android.presplash_color = #05050A
android.icon.filename = %(source.dir)s/assets/icon.png
p4a.branch = master
android.enable_androidx = True
android.add_compile_options = --add-opens=java.base/java.nio=ALL-UNNAMED

[buildozer]
log_level = 2
warn_on_root = 0
